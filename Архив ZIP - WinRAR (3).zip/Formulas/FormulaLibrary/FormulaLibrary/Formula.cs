﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormulaLibrary
{
    public class Formula
    {
        public double FormulaA(double x, double y)
        {
            double a = Math.Round((2 * Math.Cos(x-x/6)) / (1 / 2 + Math.Pow(Math.Sin(y), 2)),3);
            return a;
        }
        public double FormulaB(double z)
        {
            double b = Math.Round(1 + (Math.Pow(z,2) / 3 + Math.Pow(z, 2) / 5),3);
            return b;
        }
    }
}
