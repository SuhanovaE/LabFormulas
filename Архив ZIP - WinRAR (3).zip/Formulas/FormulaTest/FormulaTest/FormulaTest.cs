﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FormulaLibrary;

namespace FormulaTest
{
    [TestClass]
    public class FormulaTest
    {
        Formula frml = new Formula();
        [TestMethod]
        
        public void TestFormula_x_9_1_y_8_5()
        {
            double x = 9.1;
            double y = 8.5;
            
            double expectedA = 0.492;
            double actualA = frml.FormulaA(x, y);
            Assert.AreEqual(expectedA, actualA);  
        }
        [TestMethod]
        public void TestFormula_z_2_7()
        {
            double z = 2.7;

            double expectedB = 4.888;
            double actualB = frml.FormulaB(z);
            Assert.AreEqual(expectedB, actualB);
        }
        [TestMethod]
        public void TestFormula_x_2_y_5()
        {
            int x = 2;
            int y = 5;

            double expectedA = -13.5;
            double actualA = frml.FormulaA(x, y);
            Assert.AreEqual(expectedA, actualA);
        }

        [TestMethod]
        public void TestFormula_z_10()
        {
            int z = 10;

            double expectedB = 1.185;
            double actualB = frml.FormulaB(z);
            Assert.AreEqual(expectedB, actualB);
        }

        [TestMethod]
        public void TestFormula_x_0_y_0()
        {
            int x = 0;
            int y = 0;

            double expectedA = 4;
            double actualA = frml.FormulaA(x, y);
            Assert.AreEqual(expectedA, actualA);
        }
        [TestMethod]
        public void TestFormula_z_0()
        {
            double z = 0;

            double expectedB = 1;
            double actualB = frml.FormulaB(z);
            Assert.AreEqual(expectedB, actualB);
        }
        [TestMethod]
        public void TestFormula_x__2__4_y__5_6()
        {
            double x = -2.4;
            double y = -5.6;

            double expectedA = -0.926;
            double actualA = frml.FormulaA(x, y);
            Assert.AreEqual(expectedA, actualA);
        }
        [TestMethod]
        public void TestFormula_z__7_7()
        {
            double z = -7.7;

            double expectedB = 32.621;
            double actualB = frml.FormulaB(z);
            Assert.AreEqual(expectedB, actualB);
        }
        [TestMethod]
        public void TestFormula_x_5_y_6_1()
        {
            int x = 5;
            double y = 6.1;

            double expectedA = -1.947;
            double actualA = frml.FormulaA(x, y);
            Assert.AreEqual(expectedA, actualA);
        }
        [TestMethod]
        public void TestFormula_z_Max()
        {
            double z = 17.96557875047287;

            double expectedB = 173.140;
            double actualB = frml.FormulaB(z);
            Assert.AreEqual(expectedB, actualB);
        }
    }
}
